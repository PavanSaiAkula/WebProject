<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Validator;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Validator::extend('password_confirmation', function ($attribute, $value, $parameters, $validator) {
            $confirmation = $parameters[0] ?? 'password_confirmation';
            return isset($validator->getData()[$confirmation]) && $value == $validator->getData()[$confirmation];
        });
    }
}
