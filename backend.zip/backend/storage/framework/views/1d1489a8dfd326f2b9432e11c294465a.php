<?php echo e($slot); ?>

<?php /**PATH /Users/sandeepysv/Desktop/code/backend/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>