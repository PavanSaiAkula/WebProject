module.exports = {
    baseUrl: "http://localhost:8000/api"
};